
function showReg(){
 document.querySelector('.card').classList.add('hidden');
 document.getElementById('reg').classList.remove('hidden');
}
